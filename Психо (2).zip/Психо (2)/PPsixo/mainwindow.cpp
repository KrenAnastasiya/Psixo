#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "dialog.h"
#include "Count.h"

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    setFixedSize(1030, 800);
    bool t1 = this->createConnection();

}
bool MainWindow::createConnection()
{
    QSqlDatabase db = QSqlDatabase::addDatabase("QMYSQL");
    db.setHostName("localhost");
    db.setDatabaseName("mysql");
    db.setUserName("root");
    db.setPassword("root");
    bool ok = db.open();
    QString s = QString::number(ok);
    return ok;

}
QSqlDatabase dbmodel::getConnetionDB(){
    return this->db;
}
void dbmodel::closeConnetion(){
    db.close();
}
MainWindow::~MainWindow()
{
    delete ui;
}


void MainWindow::on_pushButton_clicked()
{
    Dialog d;

    d.my_count=0;
    d.t.resetResScore();

    d.t.setName("уровень внимательности");
    d.t.setInfo("Есть люди, которые всегда начеку — ничто их не может удивить, ошеломить, поставить в тупик. Им противоположность - люди рассеянные и невнимательные, теряющиеся в простейших ситуациях. Определите уровень своей внимательности. Ответьте «да» или «нет» на следующие вопросы.");
    d.t.setQNum(15);

     QSqlQuery query;
     query.prepare("SELECT id, question FROM Question1");
     query.exec();
     int i=0;

     while (query.next())
     {

         QSqlQuery query1;
         query1.prepare("SELECT * FROM Answer1 WHERE id=?");
         query1.addBindValue(QVariant(query.value(0).toString()));
         query1.exec();
         query1.next();
         d.t.questions[i].setText(query.value(1).toString());
             d.t.questions[i].setNum(2);
             d.t.questions[i].setAnswer(0,"да");
             d.t.questions[i].setAnswer(1,"нет");
             d.t.questions[i].setScore(0,query1.value(1).toInt());
             d.t.questions[i].setScore(1,query1.value(2).toInt());
       i++;
     }
     d.t.setResNum(3);

     d.t.setKey(0,0);
     d.t.setRes(0,"Вы очень рассеянны, и это является причиной многих неприятностей в Вашей жизни. Что значит, например, забыть завернуть водопроводный кран или потерять взятую у кого-то редкую книгу? Бывает, что люди даже бравируют своей рассеянностью, хотя, если разобраться, это качество отрицательное. В зрелые годы и особенно в молодые каждому под силу перебороть свою невнимательность, воспитать собранность и постоянно тренировать память.");

     d.t.setKey(1,5);
     d.t.setRes(1,"Вы достаточно внимательны, не забываете ничего важного. Однако, как говорится, и на старуху бывает проруха — кое-что можете запамятовать. Иногда проявляете рассеянность, что оборачивается досадными недоразумениями. И все же Вы способны в ответственный момент сосредоточиться и не допустить какой-либо промашки.");

     d.t.setKey(2,9);
     d.t.setRes(2," Вы удивительно внимательны и проницательны. Такой памяти и такой внимательности остается только позавидовать — это дано не каждому.");


     d.showOut();
      d.exec();
}
void MainWindow::on_pushButton_2_clicked()
{
    Dialog d;

    d.my_count=0;
    d.t.resetResScore();

    d.t.setName("Вы прагматик или мечтатель?");
    d.t.setInfo("Как понять, кто вы по складу характера? Для того чтобы изменить свою жизнь к лучшему, надо сначала представить, что тебе нужно, затем очень этого захотеть. Фантазии и мечты уравновешивают прагматичный подход. Именно с них нередко начинается движение вперед. Хотя любая фантазия легко может превратиться в средство ухода от реальности. Одним словом, во всем необходимо равновесие, и насколько его удается вам сохранять, поможет определить тест.");
    d.t.setQNum(17);


     QSqlQuery query;
     query.prepare("SELECT id, question FROM Question2");
     query.exec();
     int i=0;

     while (query.next())
     {

         QSqlQuery query1;
         query1.prepare("SELECT * FROM Answer2 WHERE id=?");
         query1.addBindValue(QVariant(query.value(0).toString()));
         query1.exec();
         query1.next();
         d.t.questions[i].setText(query.value(1).toString());
             d.t.questions[i].setNum(2);
             d.t.questions[i].setAnswer(0,"да");
             d.t.questions[i].setAnswer(1,"нет");
             d.t.questions[i].setScore(0,query1.value(1).toInt());
             d.t.questions[i].setScore(1,query1.value(2).toInt());
       i++;
     }
     d.t.setResNum(4);

     d.t.setKey(0,25);
     d.t.setRes(0,"Если вы полагаете, что предаваться мечтам и фантазировать – значит в пустую тратить время, то вы заблуждаетесь. В разумных пределах это основа любой творческой деятельности. Разрешите себе иногда помечтать, что поможет вам полнее раскрыть свой творческий потенциал.");

     d.t.setKey(1,50);
     d.t.setRes(1,"Судя по всему, вам удалось найти золотую середину между иллюзиями и реальностью. Несмотря на то что вам свойственна некоторая мечтательность, вы вполне соизмеряете ее с действительными возможностями.");

     d.t.setKey(2,65);
     d.t.setRes(2," Для вас существует риск забыться, увлекшись своими мечтами. Хотя в целом вы способны трезво смотреть на вещи. Старайтесь уделять больше внимания поступающей информации и анализу ситуации!");

     d.t.setKey(3,80);
     d.t.setRes(3,"Пожалуй, вы прячетесь от действительности, предпочитая не решать проблемы, а уходить от них в мир своих грез и фантазий. Если вы хотите оградить себя от неприятностей, смотрите на вещи реальнее.");

     d.showOut();
      d.exec();
}
void MainWindow::on_pushButton_3_clicked()
{
    Dialog d;

    d.my_count=0;
    d.t.resetResScore();

    d.t.setName("Каков уровень Вашего воображения?");
    d.t.setInfo("Вам предлагается 12 вопросов. На них надо отвечать либо 'да', либо 'нет'.");
    d.t.setQNum(12);


     QSqlQuery query;
     query.prepare("SELECT id, question FROM Question3");
     query.exec();
     int i=0;

     while (query.next())
     {

         QSqlQuery query1;
         query1.prepare("SELECT * FROM Answer3 WHERE id=?");
         query1.addBindValue(QVariant(query.value(0).toString()));
         query1.exec();
         query1.next();
         d.t.questions[i].setText(query.value(1).toString());
             d.t.questions[i].setNum(2);
             d.t.questions[i].setAnswer(0,"да");
             d.t.questions[i].setAnswer(1,"нет");
             d.t.questions[i].setScore(0,query1.value(1).toInt());
             d.t.questions[i].setScore(1,query1.value(2).toInt());
       i++;
     }
     d.t.setResNum(3);

     d.t.setKey(0,8);
     d.t.setRes(0,"Вы реалист в полном смысле этого слова. В облаках не витаете. Однако немного фантазии еще никому не вредило.");

     d.t.setKey(1,11);
     d.t.setRes(1,"У Вас среднее воображение. Такое воображение встречается у очень многих людей. От Вас и только от Вас зависит, сумеете ли Вы развить его.");

     d.t.setKey(2,15);
     d.t.setRes(2," Вы реалист в полном смысле этого слова. В облаках не витаете. Однако немного фантазии еще никому не вредило.");



     d.showOut();
      d.exec();
}
void MainWindow::on_pushButton_4_clicked()
{
    Dialog d;

    d.my_count=0;
    d.t.resetResScore();

    d.t.setName("Любите ли Вы себя");
    d.t.setInfo("Чтобы Вас полюбили окружающие, Вам нужно для начала полюбить себя – со всеми недостатками и достоинствами. Это аксиома. Комплексы, низкая самооценка, жесткая самокритика вряд ли хорошие помощники на пути к счастью, гармонии и успеху. Другое дело – когда Вы цените сами себя, знаете свои сильные стороны. Главное – не перейти границу, где начинается завышенная самооценка. Давайте проверим, насколько Вы любите себя.");
    d.t.setQNum(10);


     QSqlQuery query;
     query.prepare("SELECT id, question FROM Question4");
     query.exec();
     int i=0;

     while (query.next())
     {

         QSqlQuery query1;
         query1.prepare("SELECT * FROM Answer4 WHERE id=?");
         query1.addBindValue(QVariant(query.value(0).toString()));
         query1.exec();
         query1.next();
         d.t.questions[i].setText(query.value(1).toString());
             d.t.questions[i].setNum(2);
             d.t.questions[i].setAnswer(0,"да");
             d.t.questions[i].setAnswer(1,"нет");
             d.t.questions[i].setScore(0,query1.value(1).toInt());
             d.t.questions[i].setScore(1,query1.value(2).toInt());
       i++;
     }
     d.t.setResNum(3);

     d.t.setKey(0,15);
     d.t.setRes(0,"Вы определенно не любите себя. Ожидаете, что с Вами случиться плохое, и, признайтесь, эти Ваши ожидания нередко сбываются. Бывают мгновения, когда Вы ненавидите себя и в результате принимаете ошибочные решения. Пришло время измениться. Подумайте об этом!");

     d.t.setKey(1,30);
     d.t.setRes(1,"Трудно сказать, любите ли Вы себя. Наверняка Вы редко думаете об этом. Вы не всегда используете все свои способности, обращая чрезмерное внимание на свои слабости, а также на слабости других. Это может Вызвать у Вас минутную неприязнь к самому себе, невозможность отвлечься от собственной личности, дарить другим внимание и любовь.");

     d.t.setKey(2,45);
     d.t.setRes(2," Вы себя любите, значит, любите и других. Это в большой степени предопределяет Ваши успехи и жизнерадостность. Благодаря этому, получаете от окружающих положительные стимулы, и корабль Вашей жизни плывет под парусами. Вы чувствуете свою необходимость и считаете, что жизнь имеет смысл. Во всяком случае, Вы способны придать ей необходимый индивидуальный смысл. Вы умеете оценивать достоинства других. Помогает Вам и то, что Вы считаете себя личностью с достоинствами и потенциальными возможностями.");



     d.showOut();
      d.exec();
}
void MainWindow::on_pushButton_5_clicked()
{
    Dialog d;

    d.my_count=0;
    d.t.resetResScore();

    d.t.setName("Насколько вы ленивы");
    d.t.setInfo("Кто-то считает лень – двигателем технического прогресса. Кто-то относится к этому явлению, как к «болячке», из-за которой можно упустить свой шанс и удачу. Люди из первой категории зачастую наблюдают за течение жизни со стороны, пропуская самое интересное, что в ней есть. Представители второй категории, как правило, находят свое предназначение, а с ним уважение и благополучие. Что ближе Вам? Узнаете, ответив на ниже приведенные вопросы.");
    d.t.setQNum(10);


     QSqlQuery query;
     query.prepare("SELECT id, question FROM Question5");
     query.exec();
     int i=0;

     while (query.next())
     {

         QSqlQuery query1;
         query1.prepare("SELECT * FROM Answer5 WHERE id=?");
         query1.addBindValue(QVariant(query.value(0).toString()));
         query1.exec();
         query1.next();
         d.t.questions[i].setText(query.value(1).toString());
             d.t.questions[i].setNum(2);
             d.t.questions[i].setAnswer(0,"да");
             d.t.questions[i].setAnswer(1,"нет");
             d.t.questions[i].setScore(0,query1.value(1).toInt());
             d.t.questions[i].setScore(1,query1.value(2).toInt());
       i++;
     }
     d.t.setResNum(3);

     d.t.setKey(0,2);
     d.t.setRes(0,"У Вас нет даже намека на лень. А крайности, говорят, вредны. Может, стоит хотя бы некоторое время проводить в бездействии. Не исключено, что это окажется полезным.");

     d.t.setKey(1,6);
     d.t.setRes(1,"Как большинство людей Вы имеете склонность к лени. Но можно сказать, что Вы в границах нормы.");

     d.t.setKey(2,9);
     d.t.setRes(2,"Вы на редкость ленивы. Вряд ли Вас кто-нибудь обвинит в излишней активности. Тут у Вас просто нет конкурентов. И все-таки следовало бы приложить усилия. Возможно, Ваша лень мешает Вам в карьере, в отношениях с окружающими. Они вынуждены компенсировать Ваше бездействие, это может озлобить их.");


     d.showOut();
      d.exec();
}
void MainWindow::on_pushButton_6_clicked()
{
    Dialog d;

    d.my_count=0;
    d.t.resetResScore();

    d.t.setName("Способны ли Вы решать проблемы самостоятельно?");
    d.t.setInfo("Небольшой тест на Вашу способность решать проблемы самостоятельно. Отвечайте на вопросы, выбирая подходящий к Вам вариант");
    d.t.setQNum(8);


     QSqlQuery query;
     query.prepare("SELECT id, question FROM Question6");
     query.exec();
     int i=0;

     while (query.next())
     {

         QSqlQuery query1;
         query1.prepare("SELECT * FROM Answer6 WHERE id=?");
         query1.addBindValue(QVariant(query.value(0).toString()));
         query1.exec();
         query1.next();
         d.t.questions[i].setText(query.value(1).toString());
             d.t.questions[i].setNum(2);
             d.t.questions[i].setAnswer(0,"да");
             d.t.questions[i].setAnswer(1,"нет");
             d.t.questions[i].setScore(0,query1.value(1).toInt());
             d.t.questions[i].setScore(1,query1.value(2).toInt());
       i++;
     }
     d.t.setResNum(3);

     d.t.setKey(0,14);
     d.t.setRes(0,"Вы легко миритесь с неприятностями, даже бедами, так как способны верно оценить их. Ценно то, что Вы не склонны жалеть себя (слабость, присущая многим). Ваше душевное равновесие достойно восхищения!");

     d.t.setKey(1,23);
     d.t.setRes(1,"Вы часто ропщете на свою судьбу. Предпочитаете выплескивать проблемы и неприятности на других Вам необходимо чье-то сочувствие. Может быть, лучше научиться владеть собой?");

     d.t.setKey(2,33);
     d.t.setRes(2,"Вы еще не справляетесь со своими бедами. Возможно, поэтому они так Вас терзают. Вы замыкаетесь, нередко жалеете себя. Будь у Вас волевой характер при хороших задатках, Вы успешно справлялись бы с проблемами и неприятными ситуациями. Они подкарауливают в жизни не только Вас.");

      d.showOut();
      d.exec();
}
