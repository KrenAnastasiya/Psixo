/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.2.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *centralWidget;
    QPushButton *pushButton;
    QLabel *label_2;
    QLabel *label_3;
    QPushButton *pushButton_2;
    QPushButton *pushButton_3;
    QLabel *label_4;
    QPushButton *pushButton_4;
    QLabel *label_5;
    QLabel *label_6;
    QPushButton *pushButton_5;
    QLabel *label_7;
    QPushButton *pushButton_6;
    QLabel *label;
    QLabel *label_8;
    QLabel *label_9;
    QLabel *label_10;
    QLabel *label_11;
    QPushButton *pushButton_7;
    QPushButton *pushButton_8;
    QLabel *label_12;
    QLabel *label_13;
    QPushButton *pushButton_9;
    QPushButton *pushButton_10;
    QMenuBar *menuBar;
    QStatusBar *statusBar;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QStringLiteral("MainWindow"));
        MainWindow->resize(1042, 790);
        centralWidget = new QWidget(MainWindow);
        centralWidget->setObjectName(QStringLiteral("centralWidget"));
        pushButton = new QPushButton(centralWidget);
        pushButton->setObjectName(QStringLiteral("pushButton"));
        pushButton->setGeometry(QRect(160, 420, 201, 23));
        label_2 = new QLabel(centralWidget);
        label_2->setObjectName(QStringLiteral("label_2"));
        label_2->setGeometry(QRect(160, 290, 197, 131));
        label_2->setPixmap(QPixmap(QString::fromUtf8("../build-PPsixo-Desktop_Qt_5_5_1_MinGW_32bit-Debug/debug/maxresdefault.png")));
        label_3 = new QLabel(centralWidget);
        label_3->setObjectName(QStringLiteral("label_3"));
        label_3->setGeometry(QRect(440, 290, 186, 131));
        label_3->setPixmap(QPixmap(QString::fromUtf8("../build-PPsixo-Desktop-Release/7LJjcUem_sQ.jpg")));
        pushButton_2 = new QPushButton(centralWidget);
        pushButton_2->setObjectName(QStringLiteral("pushButton_2"));
        pushButton_2->setGeometry(QRect(440, 420, 181, 31));
        pushButton_3 = new QPushButton(centralWidget);
        pushButton_3->setObjectName(QStringLiteral("pushButton_3"));
        pushButton_3->setGeometry(QRect(700, 420, 191, 31));
        label_4 = new QLabel(centralWidget);
        label_4->setObjectName(QStringLiteral("label_4"));
        label_4->setGeometry(QRect(700, 290, 186, 131));
        label_4->setPixmap(QPixmap(QString::fromUtf8("../build-PPsixo-Desktop-Release/ISQ09oqDXLQ.jpg")));
        pushButton_4 = new QPushButton(centralWidget);
        pushButton_4->setObjectName(QStringLiteral("pushButton_4"));
        pushButton_4->setGeometry(QRect(180, 560, 181, 23));
        label_5 = new QLabel(centralWidget);
        label_5->setObjectName(QStringLiteral("label_5"));
        label_5->setGeometry(QRect(170, 450, 201, 111));
        label_5->setPixmap(QPixmap(QString::fromUtf8("../build-PPsixo-Desktop-Release/kV4OX5NHpCM.jpg")));
        label_6 = new QLabel(centralWidget);
        label_6->setObjectName(QStringLiteral("label_6"));
        label_6->setGeometry(QRect(430, 450, 211, 121));
        label_6->setPixmap(QPixmap(QString::fromUtf8("../build-PPsixo-Desktop-Release/YSetiBu1SoU.jpg")));
        pushButton_5 = new QPushButton(centralWidget);
        pushButton_5->setObjectName(QStringLiteral("pushButton_5"));
        pushButton_5->setGeometry(QRect(440, 570, 181, 23));
        label_7 = new QLabel(centralWidget);
        label_7->setObjectName(QStringLiteral("label_7"));
        label_7->setGeometry(QRect(700, 450, 191, 121));
        label_7->setPixmap(QPixmap(QString::fromUtf8("../build-PPsixo-Desktop-Release/Kak-reshit-problemu.png")));
        pushButton_6 = new QPushButton(centralWidget);
        pushButton_6->setObjectName(QStringLiteral("pushButton_6"));
        pushButton_6->setGeometry(QRect(710, 570, 181, 23));
        label = new QLabel(centralWidget);
        label->setObjectName(QStringLiteral("label"));
        label->setGeometry(QRect(10, 0, 1024, 768));
        label->setPixmap(QPixmap(QString::fromUtf8("../build-PPsixo-Desktop_Qt_5_5_1_MinGW_32bit-Debug/debug/Main.png")));
        label_8 = new QLabel(centralWidget);
        label_8->setObjectName(QStringLiteral("label_8"));
        label_8->setGeometry(QRect(840, 90, 128, 128));
        label_8->setPixmap(QPixmap(QString::fromUtf8("../../\320\237\321\201\320\270\321\205\320\276 (2)/build-PPsixo-Desktop_Qt_5_5_1_MinGW_32bit-Debug/evilminionicon.png")));
        label_9 = new QLabel(centralWidget);
        label_9->setObjectName(QStringLiteral("label_9"));
        label_9->setGeometry(QRect(10, 0, 191, 21));
        label_9->setPixmap(QPixmap(QString::fromUtf8("../../\321\200\320\265\320\271\321\202\320\270\320\275\320\263.jpg")));
        label_10 = new QLabel(centralWidget);
        label_10->setObjectName(QStringLiteral("label_10"));
        label_10->setGeometry(QRect(10, 0, 191, 31));
        label_10->setTextFormat(Qt::PlainText);
        label_10->setPixmap(QPixmap(QString::fromUtf8("../build-PPsixo-Desktop-Debug/\321\200\320\265\320\271\321\202\320\270\320\275\320\263.jpg")));
        label_11 = new QLabel(centralWidget);
        label_11->setObjectName(QStringLiteral("label_11"));
        label_11->setGeometry(QRect(706, 10, 131, 51));
        label_11->setPixmap(QPixmap(QString::fromUtf8("../build-PPsixo-Desktop-Debug/mark.png")));
        pushButton_7 = new QPushButton(centralWidget);
        pushButton_7->setObjectName(QStringLiteral("pushButton_7"));
        pushButton_7->setGeometry(QRect(850, 10, 51, 51));
        QIcon icon;
        icon.addFile(QStringLiteral("../build-PPsixo-Desktop_Qt_5_5_1_MinGW_32bit-Debug/debug/dislike.jpg"), QSize(), QIcon::Normal, QIcon::Off);
        pushButton_7->setIcon(icon);
        pushButton_8 = new QPushButton(centralWidget);
        pushButton_8->setObjectName(QStringLiteral("pushButton_8"));
        pushButton_8->setGeometry(QRect(910, 10, 51, 51));
        QIcon icon1;
        icon1.addFile(QStringLiteral("../build-PPsixo-Desktop_Qt_5_5_1_MinGW_32bit-Debug/debug/Like.jpg"), QSize(), QIcon::Normal, QIcon::Off);
        pushButton_8->setIcon(icon1);
        label_12 = new QLabel(centralWidget);
        label_12->setObjectName(QStringLiteral("label_12"));
        label_12->setGeometry(QRect(70, 30, 61, 51));
        QFont font;
        font.setPointSize(25);
        label_12->setFont(font);
        label_13 = new QLabel(centralWidget);
        label_13->setObjectName(QStringLiteral("label_13"));
        label_13->setGeometry(QRect(420, 630, 301, 21));
        pushButton_9 = new QPushButton(centralWidget);
        pushButton_9->setObjectName(QStringLiteral("pushButton_9"));
        pushButton_9->setGeometry(QRect(420, 600, 291, 27));
        pushButton_10 = new QPushButton(centralWidget);
        pushButton_10->setObjectName(QStringLiteral("pushButton_10"));
        pushButton_10->setGeometry(QRect(820, 70, 161, 27));
        QIcon icon2;
        icon2.addFile(QStringLiteral("../build-PPsixo-Desktop_Qt_5_5_1_MinGW_32bit-Debug/debug/home.png"), QSize(), QIcon::Normal, QIcon::Off);
        pushButton_10->setIcon(icon2);
        MainWindow->setCentralWidget(centralWidget);
        label->raise();
        pushButton->raise();
        label_2->raise();
        label_3->raise();
        pushButton_2->raise();
        pushButton_3->raise();
        label_4->raise();
        pushButton_4->raise();
        label_5->raise();
        label_6->raise();
        pushButton_5->raise();
        label_7->raise();
        pushButton_6->raise();
        label_8->raise();
        label_9->raise();
        label_10->raise();
        label_11->raise();
        pushButton_7->raise();
        pushButton_8->raise();
        label_12->raise();
        label_13->raise();
        pushButton_9->raise();
        pushButton_10->raise();
        menuBar = new QMenuBar(MainWindow);
        menuBar->setObjectName(QStringLiteral("menuBar"));
        menuBar->setGeometry(QRect(0, 0, 1042, 25));
        MainWindow->setMenuBar(menuBar);
        statusBar = new QStatusBar(MainWindow);
        statusBar->setObjectName(QStringLiteral("statusBar"));
        MainWindow->setStatusBar(statusBar);

        retranslateUi(MainWindow);

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QApplication::translate("MainWindow", "Psixo", 0));
        pushButton->setText(QApplication::translate("MainWindow", "\320\242\320\265\321\201\321\202 \320\275\320\260 \320\262\320\275\320\270\320\274\320\260\321\202\320\265\320\273\321\214\320\275\320\276\321\201\321\202\321\214", 0));
        label_2->setText(QString());
        label_3->setText(QString());
        pushButton_2->setText(QApplication::translate("MainWindow", "\320\222\321\213 \320\277\321\200\320\260\320\263\320\274\320\260\321\202\320\270\320\272?", 0));
        pushButton_3->setText(QApplication::translate("MainWindow", "\320\222\320\276\320\276\320\261\321\200\320\260\320\266\320\265\320\275\320\270\320\265", 0));
        label_4->setText(QString());
        pushButton_4->setText(QApplication::translate("MainWindow", "\320\233\321\216\320\261\320\270\321\202\320\265 \320\273\320\270 \320\262\321\213 \321\201\320\265\320\261\321\217", 0));
        label_5->setText(QString());
        label_6->setText(QString());
        pushButton_5->setText(QApplication::translate("MainWindow", "\320\233\320\265\320\275\320\270\320\262\321\213 \320\273\320\270 \320\262\321\213?", 0));
        label_7->setText(QString());
        pushButton_6->setText(QApplication::translate("MainWindow", "\320\241\320\260\320\274\320\276\321\201\321\202\320\276\321\217\321\202\320\265\320\273\321\214\320\275\320\276\321\201\321\202\321\214", 0));
        label->setText(QString());
        label_8->setText(QString());
        label_9->setText(QString());
        label_10->setText(QString());
        label_11->setText(QString());
        pushButton_7->setText(QApplication::translate("MainWindow", "+1", 0));
        pushButton_8->setText(QApplication::translate("MainWindow", "-1", 0));
        label_12->setText(QString());
        label_13->setText(QString());
        pushButton_9->setText(QApplication::translate("MainWindow", "\320\237\320\276\321\201\320\274\320\276\321\202\321\200\320\265\321\202\321\214 \320\277\320\276\321\201\320\273\320\265\320\264\320\275\320\270\320\271 \320\272\320\276\320\274\320\274\320\265\320\275\321\202\320\260\321\200\320\270\320\271", 0));
        pushButton_10->setText(QApplication::translate("MainWindow", "\320\233\320\270\321\207\320\275\321\213\320\271 \320\272\320\260\320\261\320\270\320\275\320\265\321\202", 0));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
