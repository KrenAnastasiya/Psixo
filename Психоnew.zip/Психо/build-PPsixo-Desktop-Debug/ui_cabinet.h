/********************************************************************************
** Form generated from reading UI file 'cabinet.ui'
**
** Created by: Qt User Interface Compiler version 5.2.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_CABINET_H
#define UI_CABINET_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QDialog>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>

QT_BEGIN_NAMESPACE

class Ui_cabinet
{
public:
    QLabel *label;
    QLabel *label_2;
    QLabel *label_3;
    QLabel *label_4;
    QLabel *label_5;
    QLabel *label_9;
    QLabel *label_6;
    QLabel *label_8;
    QLabel *label_7;
    QLabel *label_10;
    QLabel *label_11;
    QLabel *label_12;
    QLabel *label_13;
    QLabel *label_14;
    QLabel *label_15;
    QLabel *label_16;
    QLabel *label_17;
    QLabel *label_18;
    QLabel *label_19;
    QLabel *label_20;
    QLabel *label_21;
    QLabel *label_22;
    QLabel *label_23;
    QLabel *label_24;
    QLabel *label_25;
    QPushButton *pushButton;
    QLabel *label_26;
    QLabel *label_27;

    void setupUi(QDialog *cabinet)
    {
        if (cabinet->objectName().isEmpty())
            cabinet->setObjectName(QStringLiteral("cabinet"));
        cabinet->resize(573, 495);
        label = new QLabel(cabinet);
        label->setObjectName(QStringLiteral("label"));
        label->setGeometry(QRect(50, 10, 411, 17));
        QFont font;
        font.setBold(true);
        font.setItalic(true);
        font.setWeight(75);
        label->setFont(font);
        label_2 = new QLabel(cabinet);
        label_2->setObjectName(QStringLiteral("label_2"));
        label_2->setGeometry(QRect(40, 40, 81, 17));
        label_2->setFont(font);
        label_3 = new QLabel(cabinet);
        label_3->setObjectName(QStringLiteral("label_3"));
        label_3->setGeometry(QRect(150, 40, 411, 17));
        label_3->setFont(font);
        label_4 = new QLabel(cabinet);
        label_4->setObjectName(QStringLiteral("label_4"));
        label_4->setGeometry(QRect(40, 70, 281, 17));
        label_4->setFont(font);
        label_4->setWordWrap(true);
        label_5 = new QLabel(cabinet);
        label_5->setObjectName(QStringLiteral("label_5"));
        label_5->setGeometry(QRect(40, 100, 521, 71));
        label_5->setFont(font);
        label_5->setWordWrap(true);
        label_9 = new QLabel(cabinet);
        label_9->setObjectName(QStringLiteral("label_9"));
        label_9->setGeometry(QRect(40, 200, 67, 17));
        label_9->setFont(font);
        label_6 = new QLabel(cabinet);
        label_6->setObjectName(QStringLiteral("label_6"));
        label_6->setGeometry(QRect(140, 200, 371, 17));
        label_6->setFont(font);
        label_8 = new QLabel(cabinet);
        label_8->setObjectName(QStringLiteral("label_8"));
        label_8->setGeometry(QRect(50, 250, 271, 17));
        label_8->setFont(font);
        label_7 = new QLabel(cabinet);
        label_7->setObjectName(QStringLiteral("label_7"));
        label_7->setGeometry(QRect(50, 290, 491, 17));
        label_7->setFont(font);
        label_7->setWordWrap(true);
        label_10 = new QLabel(cabinet);
        label_10->setObjectName(QStringLiteral("label_10"));
        label_10->setGeometry(QRect(140, 330, 401, 17));
        label_10->setFont(font);
        label_11 = new QLabel(cabinet);
        label_11->setObjectName(QStringLiteral("label_11"));
        label_11->setGeometry(QRect(50, 400, 501, 91));
        label_11->setFont(font);
        label_11->setWordWrap(true);
        label_12 = new QLabel(cabinet);
        label_12->setObjectName(QStringLiteral("label_12"));
        label_12->setGeometry(QRect(50, 370, 251, 17));
        label_12->setFont(font);
        label_13 = new QLabel(cabinet);
        label_13->setObjectName(QStringLiteral("label_13"));
        label_13->setGeometry(QRect(40, 330, 67, 17));
        label_13->setFont(font);
        label_14 = new QLabel(cabinet);
        label_14->setObjectName(QStringLiteral("label_14"));
        label_14->setGeometry(QRect(140, 520, 391, 17));
        label_14->setFont(font);
        label_15 = new QLabel(cabinet);
        label_15->setObjectName(QStringLiteral("label_15"));
        label_15->setGeometry(QRect(50, 580, 501, 71));
        label_15->setFont(font);
        label_15->setWordWrap(true);
        label_16 = new QLabel(cabinet);
        label_16->setObjectName(QStringLiteral("label_16"));
        label_16->setGeometry(QRect(50, 550, 291, 17));
        label_16->setFont(font);
        label_17 = new QLabel(cabinet);
        label_17->setObjectName(QStringLiteral("label_17"));
        label_17->setGeometry(QRect(50, 520, 67, 17));
        label_17->setFont(font);
        label_18 = new QLabel(cabinet);
        label_18->setObjectName(QStringLiteral("label_18"));
        label_18->setGeometry(QRect(140, 650, 351, 17));
        label_18->setFont(font);
        label_19 = new QLabel(cabinet);
        label_19->setObjectName(QStringLiteral("label_19"));
        label_19->setGeometry(QRect(50, 710, 501, 71));
        label_20 = new QLabel(cabinet);
        label_20->setObjectName(QStringLiteral("label_20"));
        label_20->setGeometry(QRect(50, 680, 291, 17));
        label_20->setFont(font);
        label_21 = new QLabel(cabinet);
        label_21->setObjectName(QStringLiteral("label_21"));
        label_21->setGeometry(QRect(50, 650, 67, 17));
        label_21->setFont(font);
        label_22 = new QLabel(cabinet);
        label_22->setObjectName(QStringLiteral("label_22"));
        label_22->setGeometry(QRect(130, 800, 211, 17));
        label_23 = new QLabel(cabinet);
        label_23->setObjectName(QStringLiteral("label_23"));
        label_23->setGeometry(QRect(40, 870, 491, 91));
        label_23->setWordWrap(true);
        label_24 = new QLabel(cabinet);
        label_24->setObjectName(QStringLiteral("label_24"));
        label_24->setGeometry(QRect(40, 830, 311, 17));
        label_25 = new QLabel(cabinet);
        label_25->setObjectName(QStringLiteral("label_25"));
        label_25->setGeometry(QRect(40, 800, 67, 17));
        pushButton = new QPushButton(cabinet);
        pushButton->setObjectName(QStringLiteral("pushButton"));
        pushButton->setGeometry(QRect(340, 10, 99, 27));
        label_26 = new QLabel(cabinet);
        label_26->setObjectName(QStringLiteral("label_26"));
        label_26->setGeometry(QRect(30, -700, 551, 881));
        label_26->setFont(font);
        label_27 = new QLabel(cabinet);
        label_27->setObjectName(QStringLiteral("label_27"));
        label_27->setGeometry(QRect(10, -220, 691, 981));
        label_27->setFont(font);
        label_27->setPixmap(QPixmap(QString::fromUtf8("../build-PPsixo-Desktop_Qt_5_5_1_MinGW_32bit-Debug/debug/wYT6Hd2vSNw.jpg")));
        label_27->raise();
        label->raise();
        label_2->raise();
        label_3->raise();
        label_4->raise();
        label_5->raise();
        label_9->raise();
        label_6->raise();
        label_8->raise();
        label_7->raise();
        label_10->raise();
        label_11->raise();
        label_12->raise();
        label_13->raise();
        label_14->raise();
        label_15->raise();
        label_16->raise();
        label_17->raise();
        label_18->raise();
        label_19->raise();
        label_20->raise();
        label_21->raise();
        label_22->raise();
        label_23->raise();
        label_24->raise();
        label_25->raise();
        pushButton->raise();
        label_26->raise();

        retranslateUi(cabinet);

        QMetaObject::connectSlotsByName(cabinet);
    } // setupUi

    void retranslateUi(QDialog *cabinet)
    {
        cabinet->setWindowTitle(QApplication::translate("cabinet", "Dialog", 0));
        label->setText(QApplication::translate("cabinet", "TextLabel", 0));
        label_2->setText(QApplication::translate("cabinet", "TextLabel", 0));
        label_3->setText(QApplication::translate("cabinet", "TextLabel", 0));
        label_4->setText(QApplication::translate("cabinet", "TextLabel", 0));
        label_5->setText(QApplication::translate("cabinet", "TextLabel", 0));
        label_9->setText(QApplication::translate("cabinet", "TextLabel", 0));
        label_6->setText(QApplication::translate("cabinet", "TextLabel", 0));
        label_8->setText(QApplication::translate("cabinet", "TextLabel", 0));
        label_7->setText(QApplication::translate("cabinet", "TextLabel", 0));
        label_10->setText(QApplication::translate("cabinet", "TextLabel", 0));
        label_11->setText(QApplication::translate("cabinet", "TextLabel", 0));
        label_12->setText(QApplication::translate("cabinet", "TextLabel", 0));
        label_13->setText(QApplication::translate("cabinet", "TextLabel", 0));
        label_14->setText(QApplication::translate("cabinet", "TextLabel", 0));
        label_15->setText(QApplication::translate("cabinet", "TextLabel", 0));
        label_16->setText(QApplication::translate("cabinet", "TextLabel", 0));
        label_17->setText(QApplication::translate("cabinet", "TextLabel", 0));
        label_18->setText(QApplication::translate("cabinet", "TextLabel", 0));
        label_19->setText(QApplication::translate("cabinet", "TextLabel", 0));
        label_20->setText(QApplication::translate("cabinet", "TextLabel", 0));
        label_21->setText(QApplication::translate("cabinet", "TextLabel", 0));
        label_22->setText(QApplication::translate("cabinet", "TextLabel", 0));
        label_23->setText(QApplication::translate("cabinet", "TextLabel", 0));
        label_24->setText(QApplication::translate("cabinet", "TextLabel", 0));
        label_25->setText(QApplication::translate("cabinet", "TextLabel", 0));
        pushButton->setText(QApplication::translate("cabinet", "\320\262\321\213\321\205\320\276\320\264", 0));
        label_26->setText(QString());
        label_27->setText(QString());
    } // retranslateUi

};

namespace Ui {
    class cabinet: public Ui_cabinet {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_CABINET_H
