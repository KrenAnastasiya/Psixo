#ifndef MAINWINDOW_H
#define MAINWINDOW_H
#include <QString>
#include <QVector>
#include <QtSql/QSql>
#include <QSqlDatabase>
#include <QSqlError>
#include <QSqlQuery>
#include "string.h"
#include <QVariant>
#include <QSqlQueryModel>
#include <QMainWindow>


namespace Ui {
class MainWindow;
}
class dbmodel
{
private:
    QSqlDatabase db;

public:
    dbmodel();
    bool connect_db();
    QSqlDatabase getConnetionDB();
    void closeConnetion();
    void addUser(QString user, QString phone, QString email);
    void addProject(QString projname,QString dstart,QString dend,QString datainfo,QString);
};

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = 0);
    bool createConnection();
    ~MainWindow();

private slots:
    void updateLable();
    void on_pushButton_clicked();
    void on_pushButton_2_clicked();
    void on_pushButton_3_clicked();
    void on_pushButton_4_clicked();
    void on_pushButton_5_clicked();
    void on_pushButton_6_clicked();


    void on_pushButton_7_clicked();

    void on_pushButton_8_clicked();
    void updateLable1();

    void on_pushButton_9_clicked();

    void on_pushButton_10_clicked();

private:
    Ui::MainWindow *ui;
};

#endif // MAINWINDOW_H
