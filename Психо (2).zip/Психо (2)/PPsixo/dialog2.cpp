#include "dialog2.h"
#include "ui_dialog2.h"

Dialog2::Dialog2(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Dialog2)
{
    ui->setupUi(this);
    setFixedSize(970, 450);
}

Dialog2::~Dialog2()
{
    delete ui;
}
void Dialog2::output(int i, QString str)
{
   ui->label->setText("ваш балл: "+ QString::number(i));
    ui->label_2->setText(str);
}

void Dialog2::on_pushButton_clicked()
{
    this->close();
}
void Dialog2::on_pushButton_2_clicked()
{
    this->close();
}
void Dialog2::on_pushButton_3_clicked()
{
    this->close();
}
void Dialog2::on_pushButton_4_clicked()
{
    this->close();
}
void Dialog2::on_pushButton_5_clicked()
{
    this->close();
}
void Dialog2::on_pushButton_6_clicked()
{
    this->close();
}


