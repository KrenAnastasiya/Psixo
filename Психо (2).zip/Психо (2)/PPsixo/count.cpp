#include "Count.h"

#include <QPushButton>
#include <QLabel>
#include <QHBoxLayout>

//-----------------------
CountWidget::CountWidget(QWidget *parent) :
        QWidget(parent), count(0)
{
    PushButton_3 = new QPushButton( "Click", this );
    connect( PushButton_3, SIGNAL(clicked()),
             this, SLOT(slotClick()));

    Label_10 = new QLabel( this );

    //QHBoxLayout *mainLayout = new QHBoxLayout;
    //mainLayout->addWidget( PushButton_3 );
    //mainLayout->addWidget( Label_10 );

    //setLayout( mainLayout );
    //this->setFixedWidth( sizeHint().width() );
}

//------------------------
void CountWidget::slotClick(){
    ++count;
    Label_10->setText( QString::number( count ) );
}
