/********************************************************************************
** Form generated from reading UI file 'enter.ui'
**
** Created by: Qt User Interface Compiler version 5.2.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_ENTER_H
#define UI_ENTER_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QDialog>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>

QT_BEGIN_NAMESPACE

class Ui_enter
{
public:
    QLabel *label;
    QLabel *label_2;
    QLineEdit *lineEdit;
    QLineEdit *lineEdit_2;
    QPushButton *pushButton;
    QPushButton *pushButton_2;
    QLabel *label_3;

    void setupUi(QDialog *enter)
    {
        if (enter->objectName().isEmpty())
            enter->setObjectName(QStringLiteral("enter"));
        enter->resize(400, 313);
        label = new QLabel(enter);
        label->setObjectName(QStringLiteral("label"));
        label->setGeometry(QRect(60, 30, 67, 17));
        label_2 = new QLabel(enter);
        label_2->setObjectName(QStringLiteral("label_2"));
        label_2->setGeometry(QRect(60, 90, 67, 17));
        lineEdit = new QLineEdit(enter);
        lineEdit->setObjectName(QStringLiteral("lineEdit"));
        lineEdit->setGeometry(QRect(60, 50, 113, 27));
        lineEdit_2 = new QLineEdit(enter);
        lineEdit_2->setObjectName(QStringLiteral("lineEdit_2"));
        lineEdit_2->setGeometry(QRect(60, 120, 113, 27));
        pushButton = new QPushButton(enter);
        pushButton->setObjectName(QStringLiteral("pushButton"));
        pushButton->setGeometry(QRect(50, 180, 99, 27));
        pushButton_2 = new QPushButton(enter);
        pushButton_2->setObjectName(QStringLiteral("pushButton_2"));
        pushButton_2->setGeometry(QRect(220, 180, 151, 27));
        label_3 = new QLabel(enter);
        label_3->setObjectName(QStringLiteral("label_3"));
        label_3->setGeometry(QRect(80, 220, 261, 51));
        QFont font;
        font.setBold(true);
        font.setItalic(true);
        font.setWeight(75);
        label_3->setFont(font);

        retranslateUi(enter);

        QMetaObject::connectSlotsByName(enter);
    } // setupUi

    void retranslateUi(QDialog *enter)
    {
        enter->setWindowTitle(QApplication::translate("enter", "Dialog", 0));
        label->setText(QApplication::translate("enter", "\320\233\320\276\320\263\320\270\320\275", 0));
        label_2->setText(QApplication::translate("enter", "\320\237\320\260\321\200\320\276\320\273\321\214", 0));
        pushButton->setText(QApplication::translate("enter", "\320\222\320\276\320\271\321\202\320\270", 0));
        pushButton_2->setText(QApplication::translate("enter", "\320\227\320\260\321\200\320\265\320\263\320\270\321\201\321\202\321\200\320\270\321\200\320\276\320\262\320\260\321\202\321\214\321\201\321\217", 0));
        label_3->setText(QString());
    } // retranslateUi

};

namespace Ui {
    class enter: public Ui_enter {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_ENTER_H
