#ifndef COUNT_H
#define COUNT_H

#include <QWidget>

class QLabel;
class QPushButton;

//---------------------------
class CountWidget : public QWidget
{
    Q_OBJECT
public:
    CountWidget(QWidget *parent = 0);

private slots:
    void slotClick();

private:
    int count;

    QLabel *Label_10;
    QPushButton *PushButton_3;

};

#endif // COUNT_H
