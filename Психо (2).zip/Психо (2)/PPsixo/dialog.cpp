#include "dialog.h"
#include "dialog2.h"
#include "ui_dialog.h"

Dialog::Dialog(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Dialog)
{
    ui->setupUi(this);
    setFixedSize(950, 450);
}

Dialog::~Dialog()
{
    delete ui;
}
void Dialog::showOut()
{

    ui->label->setText(t.getName());
    ui->label_2->setText(t.getInfo());
    ui->label_3->setText(t.questions[my_count].getText());
    ui->label_5->setText(QString::number(my_count+1)+"/"+QString::number(t.getQNum()));
    ui->radioButton->setText(t.questions[my_count].getAnswer(0));
    ui->radioButton_2->setText(t.questions[my_count].getAnswer(1));

}

void Dialog::on_pushButton_clicked()
{
    if(my_count<t.getQNum()-1)
    {
        if(ui->radioButton->isChecked())
        {
            t.reply(my_count,0);
            my_count++;
            showOut();
        }
        else
        {
            if(ui->radioButton_2->isChecked())
            {
                t.reply(my_count,1);
                my_count++;
                showOut();
            }

        }
    }
    else
    {
        Dialog2 d2;
        this->close();
        d2.output(t.getResScore(),t.getRes(t.testResult()));
        d2.exec();

    }
}
    void Dialog::on_pushButton_2_clicked()
    {
        if(my_count<t.getQNum()-1)
        {
            if(ui->radioButton->isChecked())
            {
                t.reply(my_count,0);
                my_count++;
                showOut();
            }
            else
            {
                if(ui->radioButton_2->isChecked())
                {
                    t.reply(my_count,1);
                    my_count++;
                    showOut();
                }

            }
        }
        else
        {
            Dialog2 d2;
            this->close();
            d2.output(t.getResScore(),t.getRes(t.testResult()));
            d2.exec();

        }



}
    void Dialog::on_pushButton_3_clicked()
    {
        if(my_count<t.getQNum()-1)
        {
            if(ui->radioButton->isChecked())
            {
                t.reply(my_count,0);
                my_count++;
                showOut();
            }
            else
            {
                if(ui->radioButton_2->isChecked())
                {
                    t.reply(my_count,1);
                    my_count++;
                    showOut();
                }

            }
        }
        else
        {
            Dialog2 d2;
            this->close();
            d2.output(t.getResScore(),t.getRes(t.testResult()));
            d2.exec();

        }



}
    void Dialog::on_pushButton_4_clicked()
    {
        if(my_count<t.getQNum()-1)
        {
            if(ui->radioButton->isChecked())
            {
                t.reply(my_count,0);
                my_count++;
                showOut();
            }
            else
            {
                if(ui->radioButton_2->isChecked())
                {
                    t.reply(my_count,1);
                    my_count++;
                    showOut();
                }

            }
        }
        else
        {
            Dialog2 d2;
            this->close();
            d2.output(t.getResScore(),t.getRes(t.testResult()));
            d2.exec();

        }



}
    void Dialog::on_pushButton_5_clicked()
    {
        if(my_count<t.getQNum()-1)
        {
            if(ui->radioButton->isChecked())
            {
                t.reply(my_count,0);
                my_count++;
                showOut();
            }
            else
            {
                if(ui->radioButton_2->isChecked())
                {
                    t.reply(my_count,1);
                    my_count++;
                    showOut();
                }

            }
        }
        else
        {
            Dialog2 d2;
            this->close();
            d2.output(t.getResScore(),t.getRes(t.testResult()));
            d2.exec();

        }



}
    void Dialog::on_pushButton_6_clicked()
    {
        if(my_count<t.getQNum()-1)
        {
            if(ui->radioButton->isChecked())
            {
                t.reply(my_count,0);
                my_count++;
                showOut();
            }
            else
            {
                if(ui->radioButton_2->isChecked())
                {
                    t.reply(my_count,1);
                    my_count++;
                    showOut();
                }

            }
        }
        else
        {
            Dialog2 d2;
            this->close();
            d2.output(t.getResScore(),t.getRes(t.testResult()));
            d2.exec();

        }



}
